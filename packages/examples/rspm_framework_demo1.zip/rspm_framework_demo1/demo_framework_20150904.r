#=========================
#demo_framework_20150904.r
#=========================
#This script demonstrates the RSPM framework as it exists on 9/4/2015. 
#Brian Gregor, Oregon Systems Analytics LLC

#Source in the cosmer functions 
#------------------------------
#In the completed framework, the functions in this script will be compiled into a package that will be loaded.
source("scripts/cosmer.r")

#Create and load the module for identifying TDM households
#---------------------------------------------------------
#In the completed framework, the module will be created as part of a package that will be loaded.
source("scripts/make_idtdmhh_module.r")
load("modules/IdTdmHouseholds.RData")

#Initialize the environment and log
#----------------------------------
#The completed framework will wrap the functions for initializing the "run environment" and the log in a function which manages all the processes for starting a model run. 
initEnv()
initLog()

#Load the saved datastore
#------------------------
#Most model runs will start with no datastore and the 'initDatastore' function will be used instead. The 'loadDatastore' function is as much a convenience for starting with an initial datastore that can be used for module development and testing. The datastore initialization also loads all of the geography.
loadDatastore("datastore_master/datastore.h5", "geography.csv")

#Load the module, check and load inputs, and check data dependencies
#-------------------------------------------------------------------
#The completed framework will not require these individual function calls. Instead, a startup function will parse the script and identify what modules will be run (contained in what packages). The function will then load the required packages and read the requirements of each module. It will then:
#1. Check all of the scenario inputs for all of the modules and throw and error if any of the inputs don't meet module specifications. The user can read the log to find out what inputs are incorrect.
#2. Load all of the scenario inputs into the datastore.
#3. Check the data to be gotten from the datastore and to be written to the datastore by all of the modules in the order that they will be executed to determine whether each module will be able to get the data it needs from the datastore when it needs it. An error will be thrown if the data will not be available for one or more modules. The user can read the log to find out what the missing data is.
checkModuleInputs("IdTdmHouseholds")
loadInputFile(IdTdmHouseholds, "TDM")
checkModuleDependencies("IdTdmHouseholds", "2050")
rm("IdTdmHouseholds")

#Run the module
#--------------
#The IdTdmHouseholds module is run by the framework 'runModule' function. This function manages the iteration of execution by the level of geography specified in the module. In this case it is the metropolitan area. For each iteration, it loads the required data from the datastore, executes the module functions, and then saves the outputs to the datastore. 
memory.size()
runModule("IdTdmHouseholds", "2050")
memory.size()

#Check the results
#-----------------
#Tabulate and print out the number of ECO workers and IMP households by metropolitan area
Marea_ <- readFromTable("2050/Marea", "Marea")
IdxFunc <- createIndex("2050", "Household", "Marea")
for (Marea in Marea_[-1]) {
  print(Marea)
  print("Households by Number of ECO Workers")
  EcoTab_ <- table(readFromTable("2050/Household", "NumEco", IdxFunc(Marea)))
  names(EcoTab_) <- paste(names(EcoTab_), "ECO Wkr")
  print(EcoTab_)
  print("Number of IMP and non-IMP Households")
  ImpTab_ <- table(readFromTable("2050/Household", "ImpHh", IdxFunc(Marea)))
  names(ImpTab_) <- c("NonIMP", "IMP")
  print(ImpTab_)
}




