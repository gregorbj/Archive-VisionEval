## RSPM Framework Demo 
**Brian Gregor, Oregon Systems Analytics LLC**  
**September 4, 2015**

This is a demonstration of the RSPM framework as it exists as of September 4, 2015. Download this entire directory and then to examine the demo, run the *demo_framework_20150904.r* script line by line to see what various parts do. Refer to the *make_idtdmhh_module.r* script in the *script* directory to see how a module is defined. Refer to the *cosmer.r* script in the same directory to examine the functions that implement the framework to date. Refer to the latest design documentation for background.